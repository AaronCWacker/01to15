---
title: MistralCoder
emoji: 👁
colorFrom: pink
colorTo: purple
sdk: gradio
sdk_version: 3.47.1
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
