---
title: MTBenchmarkForGPTMetricsEval
emoji: 🏔️🤖🎯
colorFrom: yellow
colorTo: pink
sdk: gradio
sdk_version: 3.35.2
app_file: app.py
pinned: false
license: other
duplicated_from: lmsys/mt-bench
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
