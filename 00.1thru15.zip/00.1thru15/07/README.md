---
title: USMLE Medical License Exam EDA
emoji: 🎓💡
colorFrom: yellow
colorTo: yellow
sdk: streamlit
sdk_version: 1.27.1
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
