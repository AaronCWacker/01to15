---
title: 🐪Llama Whisper🦙 Voice Chat 🌟
emoji: 🐪🦙
colorFrom: red
colorTo: red
sdk: streamlit
sdk_version: 1.26.0
app_file: app.py
pinned: true
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference