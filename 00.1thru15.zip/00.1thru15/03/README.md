---
title: ✍️🏭 Prompt Refinery - Text to Image 🏭✍️ Gradio
emoji: ✍️🏭
colorFrom: green
colorTo: yellow
sdk: gradio
sdk_version: 3.15.0
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference